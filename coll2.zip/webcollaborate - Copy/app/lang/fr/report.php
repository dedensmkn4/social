<?php
return [
    'report-content' => 'Report content',
    'type' => 'Report Type',
    'url' => 'Report URL',
    'reason' => 'Report Reason',
    'reason-note' => 'Please provide reason for reporting this content',
    'now' => 'Report Now',
    'error' => "Failed : Please provide reasons for reporting this",
];