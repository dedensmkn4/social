<?php
return [
    'liked' => 'liked',
    'like' => 'Like',
    'unlike' => 'Unlike',
    'people-like' => 'People who like this post',
    'likes' => 'Likes'
];