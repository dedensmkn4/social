<?php
return [
    'trending-hashtag' => 'Trending #Hashtags',
    'hashtags' => '#Hashtags',

];