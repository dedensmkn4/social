<?php
return [
    'treeview' => 'Tree View',
    'treeview-info' => 'Tree View Info'
];