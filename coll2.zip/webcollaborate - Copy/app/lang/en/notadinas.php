<?php
return [
    'notadinas' => 'Nota Dinas',
];