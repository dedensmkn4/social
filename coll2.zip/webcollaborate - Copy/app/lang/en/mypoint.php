<?php 
return [
    'mypoint' => 'My Points',
    'yourpoint' => 'Your Points',
    'earnpoint' => 'Earn Point',
    'redeempoint' => 'Redeem Point',
    'historypoint' => 'History Point',   
];