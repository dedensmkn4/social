<?php

return [
    'theme-management' => 'Theme Management',
    'theme-preview' => 'Theme Preview',
    'theme-details' => 'Theme Details',
    'author-name' => 'Author Name'
];