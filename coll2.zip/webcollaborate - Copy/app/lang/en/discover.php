<?php
return [
    'discover-post' => 'Discover Posts',
    '@mention' => 'Mention',
    'discover-communities' => 'Discover Community',

    'discover' => 'Discover',
    'discover-note' => 'Discover trending posts, pages, communities and also post you are been mentioned. e.t.c.',
    'no-post' => 'Currently No post is found....Please try again later',
    'no-mention' => 'Nobody has mention you in any post',

];