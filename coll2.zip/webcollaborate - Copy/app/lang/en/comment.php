<?php
return [
    'view-more-comment' => 'View more comments',
    'post-a-comment' => 'Add a comment',
    'confirm-delete' => 'Do you really want to delete this',
    'comments' => 'comments',


    //version1.4
    'comment' => 'comment'
];