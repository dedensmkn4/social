<?php 
return [
    'ecorner' => 'Ecorner',
    'ecorner-info' => 'Info Ecorner',
    'ecorner-hc' => 'HC Care',
    'ecorner-kk' => 'Konsultasi Kesehatan',
    'ecorner-fc' => 'Fitness Center',
    'ecorner-sc' => 'Smart Cafe',
    'booking-hc' => 'Booking Hc Care',
    'booking-kk' => 'Booking Konsultasi Kesehatan',
    'booking-fc' => 'Booking Fitness Center',
    'booking-sc' => 'Booking Smart Cafe',
    'info-hc' => 'Info HC Care',
    'info-kk' => 'Info Konsultasi Kesehatan',
    'info-fc' => 'Info Fitness Center',
    'info-sc' => 'Info Smart Cafe',
    'history' => 'History Ecorner'
];