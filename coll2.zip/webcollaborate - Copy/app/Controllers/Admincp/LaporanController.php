<?php

namespace App\Controllers\Admincp;

use App\Repositories\LaporanRepository;

/**
*
*@author : Tiamiyu waliu
*@website : http://www.iDocrea8.com
*/
class LaporanController extends AdmincpController
{
    public function __construct(LaporanRepository $laporanRepository)
    {
#        die("AAA");
        parent::__construct();
        $this->activePage('laporan');
        $this->laporanRepository = $laporanRepository;

    }

    public function lists()
    {
        $type = \Input::get('type', 'post');
#        die("MMMM");

        $hasil =  $this->theme->view('laporan.lists', ['laporans' => $this->laporanRepository->lists($type), 'type' => $type])->render();
#        $hasil =  $this->theme->view('laporan.lists', ['laporans' => $this->laporanRepository->userpost($type), 'type' => $type])->render();
		return $hasil;
		#	  $laporan = app('App\\Repositories\\LaporanRepository')->userpost();
#		die($laporan);
#		return $laporan;
 }

    public function delete($id)
    {
#        $this->reportRepository->delete($id);

        return \Redirect::to(\URL::previous());
    }
}