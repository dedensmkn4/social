<?php

namespace App\Controllers\Admincp;

use App\Repositories\PostRepository;

/**
*
*@author : Tiamiyu waliu
*@website : http://www.iDocrea8.com
*/
class PostController extends AdmincpController
{
    public function __construct(PostRepository $postRepository)
    {
        parent::__construct();
        $this->postRepository = $postRepository;
    }

    public function lists()
    {
        $this->setTitle('Posts');
        return $this->theme->view('post.lists', ['posts' => $this->postRepository->listAll(\Input::get('term'))])->render();
    }
	
	public function pin()
    {
		$action = \Input::get('action');
		$id = \Input::get('id');

        $pin = $this->postRepository->pin($action, $id);

        return \Redirect::to(\URL::previous());
	}
}