<?php
namespace App\Controllers\Admincp;

use App\Repositories\StatRepository;


class StatController extends AdmincpController
{
   
    public function __construct(

    )
    {
        parent::__construct();

        $this->forgetBeforeFilter('maintenance');

        $this->theme = \Theme::type('admincp')
            ->current(\ThemeManager::getActive('admincp'))
            ->reBoot()
            ->layout('layouts.default');

        $this->activePage('dashboard');
    }

    public function activePage($page)
    {
        $this->theme->share('activePage', $page);
    }

    public function setTitle($title = null)
    {
        $this->theme->setTitle('Admincp >> '.$title);
    }

    public function dashboard()
    {
        return $this->theme->view('stat.index')->render();
    }
   
   
}
