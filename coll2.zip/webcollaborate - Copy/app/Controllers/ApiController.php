<?php

namespace App\Controllers;
use App\Repositories\PageRepository;
use App\Repositories\PostRepository;
use App\Repositories\UserRepository;
use DB;
use Exception;
use PDOException;

/**
*
*@author: Tiamiyu waliu kola
*@website : www.crea8social.com
*/
class ApiController extends \BaseController
{
    public function __construct(
        UserRepository $userRepository,
        PostRepository $postRepository,
        PageRepository $pageRepository
    )
    {
        $this->userRepository = $userRepository;
        $this->postRepository = $postRepository;
        $this->pageRepository = $pageRepository;
    }

    public function get()
    {
        $type = \Input::get('type');
        $get = \Input::get('get');
        $id = \Input::get('id');

        $errorResult = json_encode([
            'status' => 'error'
        ]);
        $result = null;

        switch($type) {
            case 'user':
                    if ($get == 'profile') {
                        $user = $this->userRepository->findByUsername($id);
                        if ($user) {
                            $result = json_encode([
                                'fullname' => $user->fullname,
                                'username' => $user->username,
                                'genre' => $user->genre,
                                'bio' => $user->bio,
                                'country' => $user->country,
                                'avatar' => $user->present()->getAvatar(600),
                                'cover' => $user->present()->coverImage(),
                                'verified' => $user->verified,
                                'id' => $user->id
                            ]);
                        }
                    } elseif($get == 'posts') {
                        $posts = $this->postRepository->timeline($id);
                        $user = $this->userRepository->findByUsername($id);
                        if (!$user) return json_encode(['posts' => []]);
                            $result = json_encode([
                                'posts' => $posts->toArray()
                            ]);

                    }
                break;

            case 'page':
                    if ($get == 'profile') {
                        $page = $this->pageRepository->get($id);
                        $result = json_encode([
                            'title' => $page->title,
                            'category' => $page->category->title,
                            'slug' => $page->slug,
                            'description' => $page->description,
                            'website' => $page->website,
                            'verified' => $page->verified,
                            'cover' => $page->present()->coverImage(),
                            'logo' => $page->present()->getAvatar(600)
                        ]);
                    } elseif($get == 'posts') {
                        $posts = $this->postRepository->pageTimeline($id);
                        $page = $this->pageRepository->get($id);

                        if (!$page) return json_encode(['posts' => []]);
                        $result = json_encode([
                            'posts' => $posts->toArray()
                        ]);

                    }
                break;
        }

        return $result;
    }

    public function gcmuser()
    {
        $result = array(
			'return'=>false,
			'msg'=>'invalid param'
		);
		// my_dump_exit($_POST);
		if (isset($_POST["name"]) && isset($_POST["email"]) && isset($_POST["regId"])) {
			// my_dump_exit($_POST);
			$name = $_POST["name"];
			$email = $_POST["email"];
			$gcm_regid = $_POST["regId"]; // GCM Registration ID
			// my_dump_exit(DB);
			// $pdo = DB::connection()->getPdo();
			// my_dump_exit($pdo);
			$deleted = DB::delete('delete from tb_gcm_users where gcm_regid = ?', [$gcm_regid]);
			$id = DB::table('gcm_users')->insertGetId(
				array(
					'name' => $name, 
					'email' => $email,
					'gcm_regid'=>$gcm_regid
				)
			);
			// my_dump_exit($id);
			// $queries = DB::getQueryLog();
			// $last_query = end($queries);
			// my_dump_exit($last_query);
			if($id!=null && $id>0){
				$registration_ids = array($gcm_regid);
				$message = array(
						'name' => $name, 
						'email' => $email,
						'gcm_regid'=>$gcm_regid,
						'id'=>$id
					);
				$res = send_GMCnotification($registration_ids, $message);
				// my_dump_exit($res);
				if($res!=false){
					$res = json_decode($res,true);
					// my_dump_exit($res);
					if(isset($res['failure']) && $res['failure']==1){
						$deleted = DB::delete('delete from tb_gcm_users where id = ?', [$id]);
						// $queries = DB::getQueryLog();
						// $last_query = end($queries);
						// my_dump_exit($last_query);
						$result = array(
							'return'=>false,
							'msg'=>$res
						);

					}else{
						$result = array(
							'return'=>true,
							'msg'=>$res
						);
					}
				}else{
					$result = array(
						'return'=>false,
						'msg'=>'Failed ID Registration'
					);
				}
			}else{
				$result = array(
					'return'=>false,
					'msg'=>'Failed ID Registration'
				);
			}
		}else if (isset($_POST["name"]) && isset($_POST["regId"])) {
			// my_dump_exit($_POST);
			$name = $_POST["name"];
			$gcm_regid = $_POST["regId"]; // GCM Registration ID
			// my_dump_exit(DB);
			// $pdo = DB::connection()->getPdo();
			// my_dump_exit($pdo);
			$deleted = DB::delete('delete from tb_gcm_users where gcm_regid = ? and name = ?', [$gcm_regid,$name]);
			
			$result = array(
				'return'=>true,
				'msg'=>$deleted
			);
		}else if (isset($_POST["message"]) && isset($_POST["regId"])) {
			// my_dump_exit($_POST);
			$message = $_POST["message"];
			$gcm_regid = $_POST["regId"]; // GCM Registration ID
			$registatoin_ids = array($gcm_regid);
			$res = send_GMCnotification($registatoin_ids, $_POST);
			if($res!=false){
				$res = json_decode($res,true);
				if(isset($res['failure']) && $res['failure']==1){
					$deleted = DB::delete('delete from tb_gcm_users where gcm_regid = ?', [$gcm_regid]);
					// $queries = DB::getQueryLog();
					// $last_query = end($queries);
					// my_dump_exit($last_query);
					$result = array(
						'return'=>false,
						'msg'=>$res
					);

				}else{
					$result = array(
						'return'=>true,
						'msg'=>$res
					);
				}
			}else{
				$result = array(
					'return'=>false,
					'msg'=>'Failed ID Registration'
				);
			}
		}
	
		header('Access-Control-Allow-Origin:*');
		header('Content-Type:application/json');
        echo json_encode($result,true);die();
    }
}