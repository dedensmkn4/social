<?php

namespace App\Controllers;
use App\Controllers\Base\UserBaseController;
use App\Repositories\PresenceRepository;

/**
*
*@author : Swamedia ID
*@website : http://www.swamedia.co.id
*/

class PresenceController extends UserBaseController
{
	public function __construct(PresenceRepository $_presencerepo)
    {
    	$this->_presencerepo = $_presencerepo;
        parent::__construct();
        $this->get_session();
    }

    public function index(){
    	return $this->preRender($this->theme->section('presence.index'), $this->setTitle(trans('presence.presence')));
    }

    public function absent(){
    	$cek_absen = $this->_presencerepo->mycurl_presence('https://myworkbook.telkom.co.id/mwb/geni/index.php?r=prsv144/check&nik='.$this->nik);
        $cek = $cek_absen['results'];
        if ($cek==0) {
    		$cek = 'Check In';
    		$catatan = 'absentmasuk';
            $note = 'How Do You Feel to Start the Day?';
   		}
        elseif ($cek==1) {
        	$cek = 'Check Out';
	    	$catatan = 'absentpulang';
            $note = 'How Do You Feel to End the Day?';
	    }
        else {
            $cek = 'Has Been Check';
            $catatan = 'Sudah absentpulang';
            $note = 'Sudah Check Out';   
        }
    	return $this->preRender($this->theme->section('presence.absent.index', ['cek' => $cek, 'catatan' => $catatan, 'note' => $note]), $this->setTitle(trans('presence.absent')));
    }

    public function activity_list(){
    	return $this->preRender($this->theme->section('presence.activity.index'), $this->setTitle(trans('presence.activity-list')));	
    }

    public function get_activity_list(){
    	$tanggal = \Input::get('tanggal');
        $cek_absen = $this->_presencerepo->mycurl_presence('https://myworkbook.telkom.co.id/mwb/geni/index.php?r=prsv144/check&nik='.$this->nik);
        $cek = $cek_absen['results'];
        if ($cek==0) {
            $cek = 'Check In';
        }
        elseif ($cek==1) {
            $cek = 'Check Out';
        }
    	$html = $this->_presencerepo->mycurl_presence('https://magenta.telkom.co.id/mwb/geni/index.php?r=prsv144/myActivity&nik='.$this->nik.'&tanggal='.$tanggal.'');
		$my_activity = $html['data'];
		$peers = $this->_presencerepo->mycurl_presence('https://magenta.telkom.co.id/mwb/geni/index.php?r=prsv144/peerActivity&nik='.$this->nik.'&tanggal='.$tanggal.'');
		$leaders = $this->_presencerepo->mycurl_presence('https://magenta.telkom.co.id/mwb/geni/index.php?r=prsv144/atsActivity&nik='.$this->nik.'&tanggal='.$tanggal.'');
		$teams = $this->_presencerepo->mycurl_presence('https://magenta.telkom.co.id/mwb/geni/index.php?r=prsv144/bwhActivity&nik='.$this->nik.'&tanggal='.$tanggal.'');
		$leaders = $leaders['data'];
        
        $settings['content'] = (String) $this->theme->section('presence.activity.get_activity', ['my_activity' => $my_activity, 'leaders' => $leaders, 'peers' => $peers, 'teams' => $teams, 'tanggal' => $tanggal, 'cek' => $cek]);
        return json_encode($settings);

    }

    public function activity_detail_list(){
        $id_activity = \Input::get('id');
        $tipe = \Input::get('tipe');
        $detail = $this->_presencerepo->mycurl_presence('https://myworkbook.telkom.co.id/mwb/geni/index.php?r=prsv144/detilActivity&id='.$id_activity.'&tipe='.$tipe.'');
        $listcomment = $this->_presencerepo->mycurl_presence('https://myworkbook.telkom.co.id/mwb/geni/index.php?r=prsv144/listComment&id='.$id_activity.'&tipe='.$tipe.'');

        return $this->preRender($this->theme->section('presence.activity.detail', ['detail' => $detail['data'], 'assign' => $detail['assign'],'listcomment' => $listcomment, 'id_activity' => $id_activity, 'assign' => $detail['assign']]), $this->setTitle(trans('presence.activity_detail_list')));
    }

    public function repot_activity(){
        $startdate = \Input::get('start_date') ? \Input::get('start_date') : date('d-m-Y', strtotime('-7 days'));
        $enddate = \Input::get('start_date') ? \Input::get('end_date') : date('d-m-Y');
        if($startdate !=null){
        $start_date = date('d-m-Y', strtotime($startdate));
        }
        else{
            $start_date = date('Y-m-d', strtotime('-7 days'));
        }
        if($enddate !=null){    
            $end_date =  date('d-m-Y', strtotime($enddate));
        }
        else{
            $end_date = date('Y-m-d');
        }
        $report = $this->_presencerepo->mycurl_presence('https://myworkbook.telkom.co.id/mwb/geni/index.php?r=prsv144/rangeActivity&nik='.$this->nik.'&tgl1='.$start_date.'&tgl2='.$end_date.'');
        $todo = $report['result']['TO DO'];
        $inprogress = $report['result']['IN PROGRESS'];
        $done = $report['result']['DONE'];
        $pending = $report['result']['PENDING'];
        $cancel = $report['result']['CANCEL'];

        return $this->preRender($this->theme->section('presence.report.activity', ['todo' => $todo, 'inprogress' => $inprogress, 'done' => $done,'pending' => $pending, 'cancel' => $cancel, 'startdate' => $startdate, 'enddate' => $enddate]), $this->setTitle(trans('presence.activity-report')));
    }

    public function repot_presence(){
        $startdate = \Input::get('start_date') ? \Input::get('start_date') : date('d-m-Y');
        $enddate = \Input::get('start_date') ? \Input::get('start_date') : date('d-m-Y');
        return $this->preRender($this->theme->section('presence.report.presence', ['startdate' => $startdate, 'enddate' => $enddate]), $this->setTitle(trans('presence.presence-report'))); 
    }

    public function repot_universal(){
        $statistik = $this->_presencerepo->mycurl_presence('https://myworkbook.telkom.co.id/mwb/geni/index.php?r=prsv144/statistik&nik='.$this->nik);
        return $this->preRender($this->theme->section('presence.report.universal', ['statistik' => $statistik['data']]), $this->setTitle(trans('presence.presence-report')));   
    }

    public function activity_add(){
        $html = $this->_presencerepo->mycurl_presence('https://myworkbook.telkom.co.id/mwb/geni/index.php?r=prsv144/myActivity&nik='.$this->nik.'&tanggal='.$this->tanggal.'&key=K60Ug3XKDO1UwvM6zy3PEWdoZCOey3');
        $todo = $this->_presencerepo->mycurl_presence('https://myworkbook.telkom.co.id/mwb/geni/index.php?r=prsv144/todolist&nik='.$this->nik.'&limit=10&offset=0');
        $my_activity = $html['data'];
        $send_task_team = $this->_presencerepo->mycurl_presence('https://myworkbook.telkom.co.id/mwb/geni/index.php?r=prsv144/listbawahan&nik='.$this->nik.'');
        $ski = $this->_presencerepo->mycurl_presence('https://magenta.telkom.co.id/mwb/geni/index.php?r=prsv144/listprogram&nik='.$this->nik.'&tahun='.date('Y').'');
        return $this->preRender($this->theme->section('presence.activity.add', ['my_activity' => $my_activity, 
                                'data_todo' => $todo['data'], 'send_task_team' => $send_task_team, 'ski' => $ski['data']]), $this->setTitle(trans('presence.activity-add')));   
    }

    public function location_detail(){
        $lat = \Input::get('lat');
        $lng = \Input::get('lng');
        $title = \Input::get('title');
        return $this->preRender($this->theme->section('presence.absent.location', ['title' => $title, 'lat' => $lat, 'lng' => $lng]), $this->setTitle(trans('presence.activity_detail_list')));
    }

    public function preRender($content, $title)
    {
        $cek_absen = $this->_presencerepo->mycurl_presence('https://myworkbook.telkom.co.id/mwb/geni/index.php?r=prsv144/check&nik='.$this->nik);
        $cek = $cek_absen['results'];
        if ($cek==0) {
            $cek_menu = 'Check In';
            $icon_check = 'in_icon.png';
        }
        elseif ($cek==1) {
            $cek_menu = 'Check Out';
            $icon_check = 'out_icon.png';
        }
        else{
            $cek_menu = 'Has Been Check';
            $icon_check = 'out_icon.png';
        }
        return $this->render('presence.layout', ['content' => $content, 'cek_menu' => $cek_menu, 'icon_check' => $icon_check], ['title' => $title]);
    }

    

}