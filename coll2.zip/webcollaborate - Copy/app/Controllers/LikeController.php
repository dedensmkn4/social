<?php

namespace App\Controllers;

use App\Controllers\Base\UserBaseController;
use App\Repositories\LikeRepository;

/**
*
*@author : Tiamiyu waliu
*@website : http://www.iDocrea8.com
*/
class LikeController extends UserBaseController
{
    public function __construct(LikeRepository $likeRepository)
    {
        $this->likeRepository = $likeRepository;
        parent::__construct();
    }

    public function like($type, $id)
    {
        if (!\Input::get('emoji')) {
			$emoji = 1;
		} else {
			$emoji = \Input::get('emoji');
		}
		$add = $this->likeRepository->add($type, $id, $emoji);
		return json_encode($add, JSON_NUMERIC_CHECK);
    }

    public function unlike($type, $id)
    {
        $remove = $this->likeRepository->remove($type, $id);
		return json_encode($remove, JSON_NUMERIC_CHECK);
    }

    public function showLikes($type, $id)
    {
        if (\Request::ajax()) {
            return $this->theme->section('likes.inline', ['likes' => $this->likeRepository->getLikes($type, $id)]);
        }
    }
	
	public function update($type, $id)
    {
        $emoji = \Input::get('emoji');
		$update = $this->likeRepository->updateEmoji($type, $id, $emoji);
		return json_encode($update, JSON_NUMERIC_CHECK);
    }
	
	public function showLike($type, $id)
    {
        if (\Request::ajax()) {
			$emoji = \Input::get('emoji');
            return $this->theme->section('likes.like', ['clike' => $this->likeRepository->getLike($type, $id, $emoji)]);
        }
    }
	
	public function showLove($type, $id)
    {
        if (\Request::ajax()) {
			$emoji = \Input::get('emoji');
            return $this->theme->section('likes.love', ['clove' => $this->likeRepository->getLove($type, $id, $emoji)]);
        }
    }
	
	public function showHaha($type, $id)
    {
        if (\Request::ajax()) {
			$emoji = \Input::get('emoji');
            return $this->theme->section('likes.haha', ['chaha' => $this->likeRepository->getHaha($type, $id, $emoji)]);
        }
    }
	
	public function showWow($type, $id)
    {
        if (\Request::ajax()) {
			$emoji = \Input::get('emoji');
            return $this->theme->section('likes.wow', ['cwow' => $this->likeRepository->getWow($type, $id, $emoji)]);
        }
    }
	
	public function showSad($type, $id)
    {
        if (\Request::ajax()) {
			$emoji = \Input::get('emoji');
            return $this->theme->section('likes.sad', ['csad' => $this->likeRepository->getSad($type, $id, $emoji)]);
        }
    }
	
	public function showAngry($type, $id)
    {
        if (\Request::ajax()) {
			$emoji = \Input::get('emoji');
            return $this->theme->section('likes.angry', ['cangry' => $this->likeRepository->getAngry($type, $id, $emoji)]);
        }
    }
	
	public function showApplause($type, $id)
    {
        if (\Request::ajax()) {
			$emoji = \Input::get('emoji');
            return $this->theme->section('likes.applause', ['capplause' => $this->likeRepository->getApplause($type, $id, $emoji)]);
        }
    }
}