<?php

namespace App\Controllers;

use App\Repositories\AdditionalPageRepository;

/**
*
*@author : Tiamiyu waliu
*@website : http://www.iDocrea8.com
*/
class AdditionalPageController extends \BaseController
{
    public function __construct(AdditionalPageRepository $additionalPageRepository)
    {
			
        parent::__construct();
        $this->additionalPageRepository = $additionalPageRepository;
    }

    public function about()
    {
		if (!\Auth::check()) {
			return \Redirect::route('user-home');
		}
		
        $page = $this->additionalPageRepository->get('about-us');

        return $this->formatRender(nl2br($page->content), $this->setTitle(trans($page->title)));
    }

    public function developers()
    {
		if (!\Auth::check()) {
			return \Redirect::route('user-home');
		}
        return $this->formatRender($this->theme->section('developers.index'), $this->setTitle('Developers'));
    }

    public function terms()
    {
		if (!\Auth::check()) {
			return \Redirect::route('user-home');
		}
        $page = $this->additionalPageRepository->get('terms-and-condition');

        return $this->formatRender(nl2br($page->content), $this->setTitle(trans($page->title)));

    }

    public function disclaimer()
    {
		if (!\Auth::check()) {
			return \Redirect::route('user-home');
		}
        $page = $this->additionalPageRepository->get('disclaimer');

        return $this->formatRender(nl2br($page->content), $this->setTitle(trans($page->title)));

    }

    public function privacy()
    {
		if (!\Auth::check()) {
			return \Redirect::route('user-home');
		}
        $page = $this->additionalPageRepository->get('privacy-policy');

        return $this->formatRender(nl2br($page->content), $this->setTitle(trans($page->title)));

    }
    public function formatRender($content, $title)
    {
		if (!\Auth::check()) {
			return \Redirect::route('user-home');
		}
        return $this->render('additional-pages.layout', ['content' => $content, 'title' => $title]);
    }
}
