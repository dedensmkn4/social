<?php

namespace App\Controllers;
use App\Controllers\Base\UserBaseController;
use App\Repositories\PresenceRepository;
	
/**
*
*@author : Swamedia ID
*@website : http://www.swamedia.co.id
*/

class FourClickController extends UserBaseController
{
	public function __construct(PresenceRepository $_presencerepo)
    {
    	$this->_presencerepo = $_presencerepo;
        parent::__construct();
        $this->get_session();
    }

    public function index(){
    	return $this->preRender($this->theme->section('fourclick.index'), $this->setTitle(trans('fourclick.fourclick')));
    }

    public function getkasus(){
    	$keyword = \Input::get('keyword');
    	$offset = \Input::get('offset');
		$data = $this->_presencerepo->mycurl_presence('https://magenta.telkom.co.id/mwb/geni/index.php?r=prsv144/filterkasus&kasus='.$keyword.'&limit=10&offset='.$offset.'');

        $reference = $data['data'][9]['hr_reference'] ? $data['data'][9]['hr_reference'] : '';
        $telis = $data['data'][9]['telis'] ? $data['data'][9]['telis'] : '';
        $definisi = $data['data'][9]['definisi'] ? $data['data'][9]['definisi'] : '';
        $settings['content'] = (String) $this->theme->section('fourclick.get_kasus', ['data' => $data, 'telis' => $telis, 'definisi' => $definisi]);

        return json_encode($settings);
    }

    public function preRender($content, $title)
    {
        return $this->render('fourclick.layout', ['content' => $content], ['title' => $title]);
    }
}    