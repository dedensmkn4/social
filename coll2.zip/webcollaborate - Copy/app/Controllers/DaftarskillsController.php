<?php
namespace App\Controllers;  
use App\Controllers\Base\UserBaseController; 
use App\Repositories\DaftarskillsRepository; 
use App\Repositories\NotificationRepository; 
use DB; 
 
 

/**
*
*@author : Tiamiyu waliu
*@website : http://www.iDocrea8.com 
*/ 
class DaftarskillsController extends UserBaseController
{ 
     public function __construct(DaftarskillsRepository $daftarskillsRepository, NotificationRepository $notificationRepository)
    {
        $this->daftarskillsRepository = $daftarskillsRepository; 
        $this->notificationRepository = $notificationRepository; 
         //return $this->theme->share('skl', $skl);  
        parent::__construct();
    } 
	  //coding by munuh  
	/*
	public function add( ) // input by tombol
    {  		
		$id = \Input::get('id');
		$skill_name = \Input::get('skill_name'); 
		$user_id = \Input::get('user_id');
		$to_user_id = \Input::get('to_user_id'); 
        $status = \Input::get('status');
		$initiate = \Input::get('initiate');  
		
        //var_dump($id);   
		//var_dump($skill_name);  
		//die('a');		
		if($status == 1 )
		{			
			$tambah = DB::insert('insert into tb_endorse_skills (initiate,user_id,to_user_id,skill,created_at,updated_at) values (?,?,?,?,now(),now())', [$initiate,$user_id,$to_user_id,$skill_name]);
            //var_dump($tambah);die();
           	$this->notificationRepository->send($to_user_id, [
				'path' => 'notification.endorse.add',
				'skill' => $skill_name
			]);
			$count = $this->getCount($to_user_id,$skill_name,$initiate);
			return json_encode($count, JSON_NUMERIC_CHECK);
        }  
	    else if ($status == 0 )
        { 	
			$tambah = DB::delete('delete from tb_endorse_skills where user_id= ? and to_user_id = ? and skill = ? ',[$user_id,$to_user_id,$skill_name]);      
			$count = $this->getCount($to_user_id,$skill_name,$initiate);
			return json_encode($count, JSON_NUMERIC_CHECK);
		}
    		
   }
   */
   
	public function add()
    {
		$user_id = \Input::get('user_id');
		$to_user_id = \Input::get('to_user_id');
		$skill_name = \Input::get('skill_name');
		$initiate = \Input::get('initiate');		
		
		$tambah = DB::insert('insert into tb_endorse_skills (initiate,user_id,to_user_id,skill,created_at,updated_at) values (?,?,?,?,now(),now())', [$initiate,$user_id,$to_user_id,$skill_name]);
		
		$this->notificationRepository->send($to_user_id, [
			'path' => 'notification.endorse.add',
			'skill' => $skill_name
		]);
		$count = $this->getCount($to_user_id,$skill_name,$initiate);
		return json_encode($count, JSON_NUMERIC_CHECK);
	}
	
	public function delete()
    {
		$user_id = \Input::get('user_id');
		$to_user_id = \Input::get('to_user_id');
		$skill_name = \Input::get('skill_name');
		$initiate = \Input::get('initiate');		
		
		$delete = DB::delete('delete from tb_endorse_skills where user_id= ? and to_user_id = ? and skill = ? ',[$user_id,$to_user_id,$skill_name]);
		
		$count = $this->getCount($to_user_id,$skill_name,$initiate);
		return json_encode($count, JSON_NUMERIC_CHECK);
	}
   
	public function getCount($to_user_id, $skill, $initiate)
    {
        return DB::select(" SELECT count(id) as counter FROM tb_endorse_skills WHERE to_user_id=? and skill=? and initiate=? ",[$to_user_id,$skill,$initiate]);
    }
   
   
}    
  
    