<?php
namespace App\Controllers;
use App\Repositories\UserRepository;

/**
 *
 *@author : Tiamiyu waliu
 *@website : http://www.iDocrea8.com
 */

class LoginController extends \BaseController {

    public function __construct(UserRepository $userRepository) {
        parent::__construct();
        $this->user = $userRepository;
        parent::__construct();
    }

    public function logout() {
        \Auth::logout();
        \Session::flush();
        //\Session::forget();
        sleep(1);
        \Auth::logout();
        if(\Auth::check()) {
            $user = \Auth::user();
            $user->last_active_time = time()- 3600;
            $user->updateStatus(0);
            $user->save();
        }
        return \Redirect::to('/');
    }

    public function login() {
        $valx = array();
        $message = null;
        if($var = \Input::get('sig')) {
            $dval = base64_decode($var);
            $dval =(json_decode($dval, true));
            //die();
            #var_dump($dval); die();
            $time = strtotime($dval['time']);
            //die();
            #var_dump(date("Y-m-d H:i:s", $time));die();
            #      if(time()-(int)$time>5) {
            $valx = array('username' =>$dval['nik']);
            #      }
            #      var_dump($valx); die("AAA");
        }
        $paramspost = \Input::get();
        $val = array();
        if(isset($paramspost['keep'])) {
            $val["keep"] = $paramspost['keep'];
        }
        if(isset($paramspost['username'])&& isset($paramspost['keypassword'])) {
            $val["username"] = $paramspost['username'];
            $val["password"] = $paramspost['keypassword'];
        }
        if($val || count($valx)> 0) {
            //var_dump($val);die();
            if(count($valx)> 0) {
                $val = $valx;
                $val['password'] = "bypass1234";
            }
              //var_dump($val);die();
            if($login = $this->user->login($val)) {
                $cache_password = \Cache::forever('password_user', $paramspost['keypassword']);
                $desUrl = \URL::route('user-home');
                if($login == 'activate') {
                    $desUrl = \URL::route('user-resend-activation');
                } elseif($login == 'banned') {
                    return \Redirect::to('/?message=' . 
                                         trans('user.user-banned'));
                    return json_encode(['response' => 0, 'message' => trans('user.user-banned'),]);
                }
                return \Redirect::to($desUrl);
            } else {
                //tambahan
                return \Redirect::to('/?message=' . 
                                     trans('user.failed-login'));
                return \Redirect::to('/logout');
                $message = trans('user.failed-login');
                return json_encode(['response' => 0, 'message' => $message,]);
            }
        }
    }

    public function forgotPassword() {
        return \Redirect::route('user-home');
        $this->setTitle(trans('user.forgot-password'));
        $message = null;
        if($email = \Input::get('email')) {
            if($this->user->retrievePassword($email)) {
                $message = trans('user.forgot-password-success');
            } else {
                $message = trans('user.forgot-password-error');
            }
        }
        return $this->theme->view('user.login.forgot-password',['message' => $message])->render();
    }

    public function retrievePassword() {
        $hash = \Input::get('hash');
        if(empty($hash))
            return \Redirect::to('/');
        if($user = $this->user->findByHash(['code' => $hash], false)) {
            $message = null;
            if($val = \Input::get('val')) {
                $validator = \Validator::make($val,['password' => 'required|confirmed']);
                if($validator->fails()) {
                    $message = $validator->messages()->first();
                } else {
                    $this->user->changePassword($val, $user);
                    \Auth::login($user);
                    return \Redirect::route('user-home');
                }
            }
            return $this->theme->view('user.login.change-password',['user' => $user, 'message' => $message])->render();
        }
    }
}
