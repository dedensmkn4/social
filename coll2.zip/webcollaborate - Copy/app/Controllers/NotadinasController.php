<?php

namespace App\Controllers;
use App\Controllers\Base\UserBaseController;

/**
*
*@author : Swamedia ID
*@website : http://www.swamedia.co.id
*/

class NotadinasController extends UserBaseController
{
	public function __construct()
    {
    	parent::__construct();
       	$this->get_session();
    }

    public function index(){
    	return $this->preRender($this->theme->section('notadinas.index'), $this->setTitle(trans('notadinas.notadinas')));
    }

    public function preRender($content, $title)
    {
        return $this->render('notadinas.layout', ['content' => $content], ['title' => $title]);
    }
}    