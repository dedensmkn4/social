<?php

namespace App\Controllers;
use App\Controllers\Base\UserBaseController;
use App\Repositories\MypointRepository;

/**
*
*@author : Swamedia ID
*@website : http://www.swamedia.co.id
*/

class MypointController extends UserBaseController
{
	public function __construct(MypointRepository $_mypointrepo)
    {
    	$this->_mypointrepo = $_mypointrepo;
        parent::__construct();
        $this->get_session();
    }

    public function index(){
    	$list_point = $this->_mypointrepo->curl_api('http://10.2.44.75:8006/mobile/param/list');
    	return $this->preRender($this->theme->section('mypoint.index', ['list_point' => $list_point['data']]), $this->setTitle(trans('mypoint.mypoint')));
    }

    public function redeempoint(){
    	$redeem = $this->_mypointrepo->curl_api('http://10.2.44.75:8006/mobile/reedem/list');
    	return $this->preRender($this->theme->section('mypoint.redeempoint', ['redeem' => $redeem['data']]), $this->setTitle(trans('mypoint.redeempoint')));
    }

    public function historypoint(){
    	return $this->preRender($this->theme->section('mypoint.historypoint'), $this->setTitle(trans('mypoint.historypoint')));
    }

    public function preRender($content, $title)
    {
        $total_point = $this->_mypointrepo->curl_api('http://10.2.44.75:8006/mobile/point/total/'.$this->nik);

        return $this->render('mypoint.layout', ['content' => $content, 'total_point' => $total_point['data']], ['title' => $title]);
    }
    
    public function point()
    {
		$total = $this->_mypointrepo->curl_api('http://10.2.44.75:8006/mobile/point/total/'.$this->nik);
		if(count($total['data']) > 0){
			return $total['data']['totalScore'];
		}else{
			return 0;
		}
	}
}    
