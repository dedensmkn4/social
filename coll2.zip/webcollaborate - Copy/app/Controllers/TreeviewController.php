<?php
namespace App\Controllers;
use App\Controllers\Base\UserBaseController;
use App\Repositories\TreeviewRepository;
use Cookie;
session_start();

class TreeviewController extends UserBaseController{
    
    public function __construct(TreeviewRepository $_treeviewrepo)
    {
		$this->_treeviewrepo = $_treeviewrepo;
        parent::__construct();
        $this->get_session();
    }
    
    public function preRender($content, $title){
        return $this->render('treeview.layout', ['content' => $content], ['title' => $title]);
    }
    
    public function index(){
		if(!isset($_SESSION['treeview'])){
			$data = '[';
			foreach($this->get() as $dt){
				$data .= '{';
				$data .= 'text: "'.explode(' | ', $dt->text)[0].'",';
				if($dt->children=="true"){
					$data .= 'nodes: [';
					foreach($this->get($dt->id) as $chil1){
						$data .= '{';
						$data .= 'text: "'.explode(' | ', $chil1->text)[0].'",';
						$data .= 'tags: [\'<i class="glyphicon glyphicon-user profile" data-no="'.$chil1->nik.'"></i>\'],';
						if($chil1->children=="true"){
							$data .= 'nodes: [';
							foreach($this->get($chil1->id) as $chil2){
								$data .= '{';
								$data .= 'text: "'.explode(' | ', $chil2->text)[0].'",';
								$data .= 'tags: [\'<i class="glyphicon glyphicon-user profile" data-no="'.$chil2->nik.'"></i>\'],';
								if($chil2->children=="true"){
									$data .= 'nodes: [';
									foreach($this->get($chil2->id) as $chil3){
										$data .= '{';
										$data .= 'text: "'.explode(' | ', $chil3->text)[0].'",';
										$data .= 'tags: [\'<i class="glyphicon glyphicon-user profile" data-no="'.$chil3->nik.'"></i>\'],';
										if($chil3->children=="true"){
											$data .= 'nodes: [';
											foreach($this->get($chil3->id) as $chil4){
												$data .= '{';
												$data .= 'text: "'.explode(' | ', $chil4->text)[0].'",';
												$data .= 'tags: [\'<i class="glyphicon glyphicon-user profile" data-no="'.$chil4->nik.'"></i>\'],';
												
												$data .= '},';
											}
											$data .= '],';
										}
										$data .= '},';
									}
									$data .= '],';
								}
								$data .= '},';
							}
							$data .= '],';
						}
						$data .= '},';
					}
					$data .= '],';
				}
				$data .= '},';
			}
			$data .= ']';
			$_SESSION['treeview'] = $data;
			//setcookie('treeview', $data, time() + (86400), "/");
			//dd($_COOKIE['treeview']);
		}else{
			if($_SESSION['treeview']!="[]"){
				$data = $_SESSION['treeview'];
			}else{
				$data = '[';
				foreach($this->get() as $dt){
					$data .= '{';
					$data .= 'text: "'.explode(' | ', $dt->text)[0].'",';
					if($dt->children=="true"){
						$data .= 'nodes: [';
						foreach($this->get($dt->id) as $chil1){
							$data .= '{';
							$data .= 'text: "'.explode(' | ', $chil1->text)[0].'",';
							$data .= 'tags: [\'<i class="glyphicon glyphicon-user profile" data-no="'.$chil1->nik.'"></i>\'],';
							if($chil1->children=="true"){
								$data .= 'nodes: [';
								foreach($this->get($chil1->id) as $chil2){
									$data .= '{';
									$data .= 'text: "'.explode(' | ', $chil2->text)[0].'",';
									$data .= 'tags: [\'<i class="glyphicon glyphicon-user profile" data-no="'.$chil2->nik.'"></i>\'],';
									if($chil2->children=="true"){
										$data .= 'nodes: [';
										foreach($this->get($chil2->id) as $chil3){
											$data .= '{';
											$data .= 'text: "'.explode(' | ', $chil3->text)[0].'",';
											$data .= 'tags: [\'<i class="glyphicon glyphicon-user profile" data-no="'.$chil3->nik.'"></i>\'],';
											if($chil3->children=="true"){
												$data .= 'nodes: [';
												foreach($this->get($chil3->id) as $chil4){
													$data .= '{';
													$data .= 'text: "'.explode(' | ', $chil4->text)[0].'",';
													$data .= 'tags: [\'<i class="glyphicon glyphicon-user profile" data-no="'.$chil4->nik.'"></i>\'],';
													
													$data .= '},';
												}
												$data .= '],';
											}
											$data .= '},';
										}
										$data .= '],';
									}
									$data .= '},';
								}
								$data .= '],';
							}
							$data .= '},';
						}
						$data .= '],';
					}
					$data .= '},';
				}
				$data .= ']';
				$_SESSION['treeview'] = $data;
				//setcookie('treeview', $data, time() + (86400), "/");
				//dd($_COOKIE['treeview']);
			}
		}
		//dd($data);
		
        $datas = array(
            'message' => '',
            'data' => $data
			//'isi' => $this->get()
		);
        
        return $this->preRender($this->theme->section('treeview.index', $datas), $this->setTitle(trans('treeview.treeview')));
    }
    
    public function get($id="null"){
        $isi = $this->_treeviewrepo->call_api("GET", "https://magenta.telkom.co.id/api_ingenium/public/ecp/treeview/".$id."/790031");
        $isis = array();
        if(!empty($isi)){
            if($isi->status=="success"){
                $isis = $isi->data;
            }
        }
        return $isis;
    }
	
	public function getDetail($id){
		$isi = $this->_treeviewrepo->call_api("GET", "https://magenta.telkom.co.id/api_ingenium/public/careerplan/mycareerplan/".$id);
        $isis = array();
		if(!empty($isi)){
			if($isi->status=="success"){
                $isis = $isi->data->parent;
			}
			
		}
        return $isis;
	}
}
