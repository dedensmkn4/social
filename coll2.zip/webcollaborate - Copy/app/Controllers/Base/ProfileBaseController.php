<?php

namespace App\Controllers\Base;

/**
*
*@author : Tiamiyu waliu
*@website : http://www.iDocrea8.com
*/
class ProfileBaseController extends UserBaseController
{
    public $profileUser;
	public $ownid;

    public function __construct()
    {
        parent::__construct();
        $this->userid = \Request::segment(1);
        $a = \Auth::user(); 
		$this->theme->share('login_user',$a);   
        $this->ownid = $this->userRepository->getProfileUser($a->username); 
        $this->theme->share('profileown', $this->ownid); 
		
        $this->profileUser = $this->userRepository->getProfileUser($this->userid);
        $this->theme->share('profileUser', $this->profileUser);
		//var_dump($this->profileUser);die();

        if (\Auth::check()) {
            $this->theme->share('viewerUser', \Auth::user());
        }
		//$uri = \Request::path();
        //var_dump($uri);  die(); 
		$this->setTitle();
		
		$this->listRecognitionRepository = app('App\Repositories\ListRecognitionRepository');
		$this->endorseRepository = app('App\Repositories\EndorseRepository');
		$this->daftarskillsRepository = app('App\Repositories\DaftarskillsRepository');
		$this->listuserRecognitionRepository = app('App\Repositories\ListuserRecognitionRepository');
		$this->recognitionRepository = app('App\Repositories\RecognitionRepository');		 
    }

    public function render($path, $param = [], $setting = [])
    {
        $predefinedSettings = [
            'title' => ''
        ];

        if ($this->exists()) {

            $predefinedSettings = array_merge($predefinedSettings, ['design' => $this->profileUser->present()->readDesign()]);
        }

        $settings = array_merge($predefinedSettings, $setting);


        if (!$this->exists()) {
            return parent::render($path, $param, $settings);
        } elseif (!$this->profileUser->present()->canViewMe()) {
            return parent::render('profile.layout', ['content' => $this->theme->section('profile.not-viewable'), 'error' => true], $settings);
        } else {
            return parent::render('profile.layout', ['content' => $this->theme->section($path, $param), 'recognitions' => $this->listRecognitionRepository->getListRecognition($this->profileUser->id), 'listuserRecognition' => $this->listuserRecognitionRepository->getListuserRecognition($this->profileUser->id), 'userRecognitions' => $this->recognitionRepository->getUserRecognition($this->profileUser->id), 'hasRecognized' => $this->recognitionRepository->getHasRecognized($this->profileUser->id)], $settings);
        }

    }

    public function profileNotFound()
    {
        if (\Config::get('disable-guest-access-profile') and !\Auth::check()) return \Redirect::to('');
        return $this->theme->section('error-page');
    }

    public function exists()
    {
        if (\Config::get('disable-guest-access-profile') and !\Auth::check()) return false;

        return $this->profileUser;
    }

    public function setTitle($title = null)
    {
        if (!$this->exists()) return parent::setTitle($title);
        $title = (!empty($title)) ? '-'.$title : null;
        $title = $this->profileUser->fullname.$title;
        return parent::setTitle($title);
    }
}
 