<?php
namespace App\Controllers;
use App\Controllers\Base\UserBaseController;
use App\Repositories\EcornerRepository;
use Illuminate\Support\Facades\Redirect;
session_start();

class EcornerController extends UserBaseController{
	
	private $dt = array();
	
    
    public function __construct(EcornerRepository $_ecornerrepo)
    {
		$this->_ecornerrepo = $_ecornerrepo;
        parent::__construct();
        $this->get_session();
    }

	public function preRender($content, $title){
        return $this->render('ecorner.layout', ['content' => $content], ['title' => $title]);
    }
	
	// ================================================================================================= //
	
	/*
	 * Group HC Care
	 * Pelayanan Pisikolog
	 * 
	**/
	
    public function hce(){
		$places = array();
		//dd(Session::get('msgs'));
		if(isset($_SESSION['message_hc'])){
			$message = $_SESSION['message_hc'];
		}else{
			$this->unset_session('info');			
			$message = "";
		}
		//$message = (isset($_SESSION['message']))? $_SESSION['message'] : "";
		
		$place = $this->_ecornerrepo->call_api("GET", "hc", "mobile/lokasi/tempat");
		//dd($place);
		if(!empty($place)){
			if(!isset($place->error)){
				if($place->status=="200"){
					$places = $place->data;
				}else{
					$message = $place->message;
				}
			}else{
				$message = $place->message;
			}
		}
		
		$data = array(
			'place' => $places,
			'message' => $message
		);
		
		return $this->preRender($this->theme->section('ecorner.hc.index', $data), $this->setTitle(trans('ecorner.ecorner-hc')));
	}
	
	public function hce_booking(){
		$val = \Input::get('val');
		if(!empty($val) && $val['date']!="" && $val['place']!="" && $val['psikolog']!="" && $val['time']!=""){
			$place = explode("|",$val['place']);
			$psikolog = explode("|",$val['psikolog']);
			$time = explode("|",$val['time']);
			//print_r($time[0]);die;
		
			/*$data = array(
				"idJadwal" => $time[0]
			);*/
			$data = array(
				"band" => $this->band,
                "divisi" => $this->divisi,
                "nama" => $this->nama,
                "nik" => $this->nik,
                "posisi" => $this->posisi,
                "unit" => $this->unit,
                "idJadwal" => $time[0]
			);
			$data = json_encode($data);
			$booking = $this->_ecornerrepo->call_api("POST", "hc", "mobile/booking/save-tmp", $data);
			if($booking->status=="200"){
				$this->unset_session();

				$data = array(
					'message'=> '',
					'kode' => $booking->data->kodeBooking,
					'date' => $val['date'],
					'place' => $place[1],
					'psikolog' => $psikolog[1],
					'time' => $time[1],
				);
				return $this->preRender($this->theme->section('ecorner.hc.booking', $data), $this->setTitle(trans('ecorner.ecorner-hc')));
			}else{
				if(isset($val['type'])) $_SESSION['info_message_hc'] = $booking->message;
				else $_SESSION['message_hc'] = $booking->message;
				
				return Redirect::back();
			}
		}	
	}
	
	public function hce_info(){
		date_default_timezone_set("Asia/Jakarta");
		$places = array();
		$infos = array();
		$psikologss = array();
		if(isset($_SESSION['info_message_hc'])){
			$message = $_SESSION['info_message_hc'];
		}else{
			$this->unset_session('message');
			$message = "";
		}
		//$message = (isset($_SESSION['info_message']))? $_SESSION['info_message'] : "";
		
		$place = $this->_ecornerrepo->call_api("GET", "hc", "mobile/lokasi/tempat");
		if(!empty($place)){
			if(!isset($place->error)){
				if($place->status=="200"){
					$places = $place->data;
				}else{
					$message = $place->message;
				}
			}else{
				$message = $place->error_description;
			}
		}
		
		$val = \Input::get('val');
		if(!empty($val)){
			if($val['psikolog']!="" && $val['place']!="" && $val['date']!=""){
				$psikolog = explode("|",$val['psikolog']);
				$place = explode("|",$val['place']);
				$date = $val['date'];
				
				// API GET Data Informasi
				$info = $this->_ecornerrepo->call_api("GET", "hc", "mobile/booking/info/".$psikolog[0]."/".$date);
				if(!empty($info)){
					if($info->status=="200"){
						$this->unset_session();
						$infos = $info->data;
					} else{
						$message = $info->message;
					}
				}else{
					$message = "API Stop";
				}
				
			}else{
				$message = "Data input tidak boleh kosong";
			}

			$psikologs = $this->_ecornerrepo->call_api("GET", "hc", "mobile/psikolog-tempat/".$date."/".$place[0]);
			if(!empty($psikologs)){
				if($psikologs->status=="200"){
					$psikologss = $psikologs->data;
				}else{
					$message = $psikologs->message;
				}
			}
		}
		
		$data = array(
			'place' => $places,
			'info' => $infos,
			'psikolog' => $psikologss,
			'message' => $message,
			'val' => $val
		);
		
		return $this->preRender($this->theme->section('ecorner.hc.info', $data), $this->setTitle(trans('ecorner.ecorner-hc')));
	}
	
	// ========================================================================================================= //
	
	/*
	 * Group Konsultasi Kesehatan
	 * Pelayanan Kesehatan ketika sakit
	 * 
	**/
	
	public function kk(){
		$places = array();
		if(isset($_SESSION['message_kk'])){
			$message = $_SESSION['message_kk'];
		}else{
			$this->unset_session('info');
			$message = "";
		}
		
		$place = $this->_ecornerrepo->call_api("GET", "kk", "mobile/lokasi/tempat");
		if(!empty($place)){
			if(!isset($place->error)){
				if($place->status=="200"){
					$places = $place->data;
				}else{
					$message = $place->message;
				}
			}else{
				$message = $place->error_description;
			}
		}
		
		$data = array(
			'place' => $places,
			'message' => $message
		);
		
		return $this->preRender($this->theme->section('ecorner.kk.index', $data), $this->setTitle(trans('ecorner.ecorner-kk')));
	}
	
	public function kk_booking(){
		$val = \Input::get('val');
		if(!empty($val) && $val['date']!="" && $val['place']!="" && $val['doctor']!="" && $val['time']!=""){
			$place = explode("|",$val['place']);
			$doctor = explode("|",$val['doctor']);
			$time = explode("|",$val['time']);
			//print_r($time[0]);die;
		
			$data = array(
                "nama" => $this->nama,
                "nik" => $this->nik,
                "idJadwal" => $time[0],
            );
			$data = json_encode($data);
			$booking = $this->_ecornerrepo->call_api("POST", "kk", "mobile/booking/save-tmp", $data);
			if($booking->status=="200"){
				$this->unset_session();
				$data = array(
					'message'=> '',
					'kode' => $booking->data->kodeBooking,
					'date' => $val['date'],
					'place' => $place[1],
					'doctor' => $doctor[1],
					'time' => $time[1],
				);
				return $this->preRender($this->theme->section('ecorner.kk.booking', $data), $this->setTitle(trans('ecorner.ecorner-kk')));
			}else{
				if(isset($val['type'])) $_SESSION['info_message_kk'] = $booking->message;
				else $_SESSION['message_kk'] = $booking->message;
				
				return Redirect::back();
			}
		}
	}
	
	public function kk_info(){
		date_default_timezone_set("Asia/Jakarta");
		$places = array();
		$info = array();
		$infos = array();
		$doctors = array();
		if(isset($_SESSION['info_message_kk'])){
			$message = $_SESSION['info_message_kk'];
		}else{
			$this->unset_session('message');
			$message = "";
		}
		
		$place = $this->_ecornerrepo->call_api("GET", "kk", "mobile/lokasi/tempat");
		if(!empty($place)){
			if(!isset($place->error)){
				if($place->status=="200"){
					$places = $place->data;
				}else{
					$message = $place->message;
				}
			}else{
				$message = "Error API";
			}
		}
		
		$val = \Input::get('val');
		if($val){
			if($val['doctor']!="" && $val['place']!="" && $val['date']!=""){
                $doctor = explode("|",$val['doctor']);
                $tmpt = explode("|",$val['place']);
                $date = $val['date'];
				
				$this->unset_session();
                
                // API GET Data Informasi
                $info = $this->_ecornerrepo->call_api("GET", "kk", "mobile/booking/info/".$doctor[0]."/".$date);
                if(!empty($info)){
                    if($info->status=="200"){
                        $infos = $info->data;
                    } else{
                        $message = $info->message;
                    }
                }else{
                    $message = "API Stop";
                }
				
				$doctor = $this->_ecornerrepo->call_api("GET", "kk", "mobile/dokter-tempat/".$date."/".$tmpt[0]);
				if(!empty($doctor)){
					if(!isset($doctor->error)){
						if($doctor->status=="200"){
							$doctors = $doctor->data;
						}else{
							$message = $doctor->message;
						}
					}else{
						$message = $doctor->error_description;
					}
				}
            }else{
                $message = "Data input tidak boleh kosong";
            }
		}
		
		$data = array(
			'place' => $places,
			'info' => $infos,
			'doctor' => $doctors,
			'val' => $val,
			'message' => $message
		);
		
		return $this->preRender($this->theme->section('ecorner.kk.info', $data), $this->setTitle(trans('ecorner.ecorner-kk')));
	}
	
	// ========================================================================================================= //
	
	/*
	 * Group Fitnnes
	 * Pelayanan Fitnnes / Olahraga
	 * 
	**/
	
	public function fc(){
		$places = array();
		if(isset($_SESSION['message_fc'])){
			$message = $_SESSION['message_fc'];
		}else{
			$this->unset_session('info');
			$message = "";
		}
		
		$place = $this->_ecornerrepo->call_api("GET", "fc", "mobile/lokasi/tempat");
		if(!empty($place)){
			if(!isset($place->error)){
				if($place->status=="200"){
					$places = $place->data;
				}else{
					$message = $place->message;
				}
			}else{
				$message = "Error API";
			}
		}
		
		$data = array(
			'place' => $places,
			'message' => $message
		);
		
		return $this->preRender($this->theme->section('ecorner.fc.index', $data), $this->setTitle(trans('ecorner.ecorner-fc')));
	}
	
	public function fc_booking(){
		$val = \Input::get('val');
		if(!empty($val) && $val['date']!="" && $val['place']!="" && $val['time']!=""){
			$place = explode("|",$val['place']);
			$service = (isset($val['service']))? explode("|",$val['service']) : "";
			$time = (isset($val['time']))?explode("|",$val['time']) : "";
			
			/*$data = array(
                'idJadwal' => (int)$time[0],
                'name' => $this->nama,
                'nik' => $this->nik
            );*/
            $data = array(
				"band" => $this->band,
                "divisi" => $this->divisi,
                "idJadwal" => $time[0],
			    "nama" => $this->nama,
                "nik" => $this->nik,
                "posisi" => $this->posisi,
                "unit" => $this->unit
            );
            
			$data = json_encode($data);
			//dd($data);
			$booking = $this->_ecornerrepo->call_api("POST", "fc", "mobile/booking/save", $data);
			if($booking->status=="200"){
				$this->unset_session();
					
				foreach($booking->data as $bookings){
                    $kode = $bookings->kodeBooking;
                }
                //dd($service);
				$data = array(
					'message'=> '',
					'kode' => $kode,
					'date' => $val['date'],
					'place' => $place[1],
					'service' => "",
					'time' => ($time!="")? $time[1] : "",
				);
				return $this->preRender($this->theme->section('ecorner.fc.booking', $data), $this->setTitle(trans('ecorner.ecorner-fc')));
			}else{
				//dd($booking);
				if(isset($val['type'])) $_SESSION['info_message_fc'] = $booking->message;
				else $_SESSION['message_fc'] = $booking->message;
				
				return Redirect::back();
			}
		}
	}
	
	public function fc_info(){
		date_default_timezone_set("Asia/Jakarta");
		$places = array();
		$info = array();
		$infos = array();
		$placess = "";
		if(isset($_SESSION['info_message_fc'])){
			$message = $_SESSION['info_message_fc'];
		}else{
			$this->unset_session('message');
			$message = "";
		}
		
		$place = $this->_ecornerrepo->call_api("GET", "fc", "mobile/lokasi/tempat");
		if(!empty($place)){
			if(!isset($place->error)){
				if($place->status=="200"){
					$places = $place->data;
				}else{
					$message = $place->message;
				}
			}else{
				$message = $place->error_description;
			}
		}
		
		$val = \Input::get('val');
		if(!empty($val) && $val['date']!="" && $val['place']!=""){
			$place = explode("|",$val['place']);
            $placess = $val['place'];
            $date = $val['date'];
			
			$this->unset_session();
			
            //dd("https://10.62.160.219:8243/diarium/ec/fc/api/v1/mobile/info_fc/".$place[0]."/".$date."/".$this->nik);
			$info = $this->_ecornerrepo->call_api("GET", "fc", "mobile/info/".$place[0]."/".$date."/".$this->nik);
            if(!empty($info)){
                if($info->status=="200"){
                    $infos = $info->data;
                }else{
                    $message = $info->message;
                }
            }else{
                $message = "API is Stop";
            }
		}
		
		$data = array(
			'place' => $places,
			'places' => $placess,
			'info' => $infos,
			'val' => $val,
			'message' => $message
		);
		
		return $this->preRender($this->theme->section('ecorner.fc.info', $data), $this->setTitle(trans('ecorner.ecorner-fc')));
	}
	
	// ========================================================================================================= //
	
	/*
	 * Group Smart Cafe
	 * Pelayanan Booking Tempat makan atau nongrong
	 * 
	**/
	
	public function sc(){
		$places = array();
		if(isset($_SESSION['message_sc'])){
			$message = $_SESSION['message_sc'];
		}else{
			$this->unset_session('info');
			$message = "";
		}
		//dd($message);
		$place = $this->_ecornerrepo->call_api("GET", "sc", "mobile/lokasi/tempat");
		if(!empty($place)){
			if(!isset($place->error)){
				if($place->status=="200"){
					$places = $place->data;
				}else{
					$message = $place->message;
				}
			}else{
				$message = "Error API";
			}
		}
		
		$data = array(
			'place' => $places,
			'message' => $message
		);
		
		return $this->preRender($this->theme->section('ecorner.sc.index', $data), $this->setTitle(trans('ecorner.ecorner-sc')));
	}
	
	public function sc_booking(){
		$val = \Input::get('val');
		if($val['date']!="" && $val['place']!="" && $val['fasilitas']!="" && $val['time']!=""){
			if($val['jumlah']!="" || $val['jumlah']!=0){
                $place = explode("|",$val['place']);
                $fasilitas = explode("|",$val['fasilitas']);
                $time = explode("|",$val['time']);
                
                /*$datas = array(
                    'idJadwal' => $time[0],
                    'jumlahOrang' => $val['jumlah'],
                    'nama' => $this->nama,
                    'nik' => $this->nik,
                    'tanggal' => $val['date']
                );*/
                $data = array(
					"band" => $this->band,
					"divisi" => $this->divisi,
					"idJadwal" => $time[0],
					"jumlahOrang" => $val['jumlah'],
					"nama" => $this->nama,
					"nik" => $this->nik,
					"posisi" => $this->posisi,
					"unit" => $this->unit
				);
                $data = json_encode($data);
                //dd($data);
                $booking = $this->_ecornerrepo->call_api("POST", "sc", "mobile/booking/save", $data);
				if($booking->status=="200"){
					$this->unset_session();

					foreach($booking->data as $bookings){
						$kode = $bookings->kodeBooking;
					}
					$datas = array(
						'kode' => $kode,
						'fasilitas' => $fasilitas[1],
						'place' => $place[1],
						'date' => $val['date'],
						'time' => $time[1],
						'jumlah' => $val['jumlah']
					);
					return $this->preRender($this->theme->section('ecorner.sc.booking', $datas), $this->setTitle(trans('ecorner.ecorner-sc')));
				}else{
                    if(isset($val['type'])) $_SESSION['info_message_sc'] = $booking->message;
					else $_SESSION['message_sc'] = $booking->message;
					return Redirect::back();
                }
            }else{
				if(isset($val['type'])) $_SESSION['info_message_sc'] = "Jumlah Orang tidak boleh kosong atau 0";
				else $_SESSION['message_sc'] = "Jumlah Orang tidak boleh kosong atau 0";
                
				return Redirect::back();
            }
		}
	}
	
	public function sc_info(){
		date_default_timezone_set("Asia/Jakarta");
		$places = array();
		$info = array();
		$infos = array();
		$fasilitass = array();
		$fasilitasss = array();
		if(isset($_SESSION['info_message_sc'])){
			$message = $_SESSION['info_message_sc'];
		}else{
			$this->unset_session('message');
			$message = "";
		}
		
		$place = $this->_ecornerrepo->call_api("GET", "sc", "mobile/lokasi/tempat");
		if(!empty($place)){
			if(!isset($place->error)){
				if($place->status=="200"){
					$places = $place->data;
				}else{
					$message = $place->message;
				}
			}else{
				$message = $place->error_description;
			}
		}
		
		$val = \Input::get('val');
		if(!empty($val)){
			if($val['place']!="" && $val['date']!="" && $val['fasilitas']!=""){
                $place = explode("|",$val['place']);
                $fasilitas = explode("|",$val['fasilitas']);
				$this->unset_session();
				
                $info = $this->_ecornerrepo->call_api("GET", "sc", "mobile/info/".$fasilitas[0]."/".$val['date']."/".$this->nik);
                if(!empty($info)){
                    if($info->status=="200"){
                        $infos = $info->data;
                    }else{
                        $message = $info->message;
                    }
                }
				
				$fasilitass = $this->_ecornerrepo->call_api("GET", "sc", "mobile/fasilitas/".$place[0]);
				if(!empty($fasilitass)){
					if($fasilitass->status=="200"){
						$fasilitasss = $fasilitass->data;
					}else{
						$message = $fasilitass->message;
					}
				}
            }else{
                $message = "Input is not empty";
            }
		}
		//dd($val);
		$data = array(
			'place' => $places,
			'fasilitas' => $fasilitasss,
			'val' => $val,
			'info' => $infos,
			'message' => $message
		);
		
		return $this->preRender($this->theme->section('ecorner.sc.info', $data), $this->setTitle(trans('ecorner.ecorner-sc')));
	}
	
	// ========================================================================================================= //
	
	/*
	 * Group History
	 * Pelayanan History kegiatan yang pernah di pesan sebelumnya
	 * 
	**/
	
	public function history(){
		$history_not_checkin = array();
		$history_available = array();
		$history_checkin = array();
		$layanan = "";
		$message = "";
		$history = "";
		$nik = $this->nik;
		
		$val = \Input::get('val');
		if($val){
			$layanan = $val['layanan'];

			if($layanan=="1"){
				// HC Care
				$history = $this->_ecornerrepo->call_api("GET", "hc", "mobile/booking/history/1/".$nik);
			}elseif($layanan=="2"){
				// Konsultasi Kesehatan
				$history = $this->_ecornerrepo->call_api("GET", "kk", "mobile/booking/history/2/".$nik);
			}elseif($layanan=="3"){
				// Fitnes Center
				$history = $this->_ecornerrepo->call_api("GET", "fc", "mobile/history/3/".$nik);
			}elseif($layanan=="4"){
				// Smart Cafe
				$history = $this->_ecornerrepo->call_api("GET", "sc", "mobile/history/4/".$nik);
			}else{
				$message = "Silahkan Pilih Layanan";
			}
			
			//dd($history);
			
			if(!empty($history)){
				if($history->status=="200"){
					$history_not_checkin = $history->data->NotCheckIn;
					$history_available = $history->data->Available;
					$history_checkin = $history->data->CheckIn;
				}else{
					$message = $history->message;
				}
			}else{
				if($layanan!="")
					$message = "API Stop";
			}	
		}
		//dd($history_not_checkin);
		
		$data = array(
            'message'=> $message,
            'history_not_checkin' => $history_not_checkin, // Booking yang kadar luarsa
            'history_available' => $history_available, // Booking yang belum di Check In
            'history_checkin' => $history_checkin, // Booking yang sudah di Check In
            'layanan' => $layanan
        );
		
		return $this->preRender($this->theme->section('ecorner.history', $data), $this->setTitle(trans('ecorner.ecorner-history')));
	}
	
	function unset_session($type=null){
		if($type=='message'){
			// message
			if(isset($_SESSION['message_hc']))
				session_unset($_SESSION['message_hc']);
			if(isset($_SESSION['message_kk']))
				session_unset($_SESSION['message_kk']);
			if(isset($_SESSION['message_fc']))
				session_unset($_SESSION['message_fc']);
			if(isset($_SESSION['message_sc']))
				session_unset($_SESSION['message_sc']);
		}elseif($type=='info'){
			// message
			if(isset($_SESSION['message_hc']))
				session_unset($_SESSION['message_hc']);
			if(isset($_SESSION['message_kk']))
				session_unset($_SESSION['message_kk']);
			if(isset($_SESSION['message_fc']))
				session_unset($_SESSION['message_fc']);
			if(isset($_SESSION['message_sc']))
				session_unset($_SESSION['message_sc']);
		}else{
			// message
			if(isset($_SESSION['message_hc']))
				session_unset($_SESSION['message_hc']);
			if(isset($_SESSION['message_kk']))
				session_unset($_SESSION['message_kk']);
			if(isset($_SESSION['message_fc']))
				session_unset($_SESSION['message_fc']);
			if(isset($_SESSION['message_sc']))
				session_unset($_SESSION['message_sc']);
			
			// info message
			if(isset($_SESSION['info_message_hc']))
				session_unset($_SESSION['info_message_hc']);
			if(isset($_SESSION['info_message_kk']))
				session_unset($_SESSION['info_message_kk']);
			if(isset($_SESSION['info_message_fc']))
				session_unset($_SESSION['info_message_fc']);
			if(isset($_SESSION['info_message_sc']))
				session_unset($_SESSION['info_message_sc']);
		}
		
		return true;
	}
    
}
