<?php

namespace App\Controllers;

use App\Controllers\Base\UserBaseController;
use App\Repositories\RecognitionRepository;

/**
*
*@author : Tiamiyu waliu
*@website : http://www.iDocrea8.com
*/
class RecognitionController extends UserBaseController
{
    public function __construct(RecognitionRepository $recognitionRepository)
    {
        $this->recognitionRepository = $recognitionRepository;
        parent::__construct();
    }
	
	public function add()
    {
		// ini_set('display_errors', 1);		
		// var_dump(\Input::get('recognition'));
		// die();
        return $this->recognitionRepository->add();
    }
	
	public function getListUser()
    { 
		 
        if (\Request::ajax()) 
		{   
			$to_user_id = \Input::get('userid');
			$recognition = \Input::get('label');    
            return $this->theme->section('profile.recognition-user', 
			['recusers' => $this->recognitionRepository->getListUser($to_user_id, $recognition)]);
        }
    }
    
}