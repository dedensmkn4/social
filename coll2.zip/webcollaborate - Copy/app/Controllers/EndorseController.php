<?php
namespace App\Controllers;
use Illuminate\Http\Request;
use App\Controllers\Base\UserBaseController; 
use App\Controllers\Base\ProfileBaseController;   
use App\Repositories\EndorseRepository;
use App\Repositories\ListSkillRepository;
use DB;

/**
*
*@author : Tiamiyu waliu
*@website : http://www.iDocrea8.com
*/
class EndorseController extends UserBaseController
{
	public $userid; 
    public function __construct(EndorseRepository $endorseRepository, ListSkillRepository $listSkillRepository)
    {
        $this->endorseRepository = $endorseRepository;
        $this->listSkillRepository = $listSkillRepository;
		 
		  
        parent::__construct(); 
		    
		  
    }
	//coding by munuh
	public function add()
    {
		// ini_set('display_errors', 1);
		// var_dump(\Input::get('skill'));
		// die();   
      	      	
      return $this->endorseRepository->add();
    }
   //coding by munuh
	public function getSkill() 	
    {            
	      
	      $a = \Auth::user(); 
		  //$this->userid = \Request::segment(1);
	      $skill = DB::select('select a.id as value, a.skill as text from tb_listskills a left join   
		           ( select * from tb_endorse_skills where to_user_id = ? ) b on a.skill = b.skill where b.skill is NULL ',[$a->id]);	   
	      return $skill;        
    }  
   //coding by munuh	
	public function getSkillother()
	{    
          //$this->adas = \Request::segment(1);	 
              
		  $skillother = DB::select('select a.id as value, a.skill as text from tb_listskills a left join   
		           ( select * from tb_endorse_skills where user_id != "'.$_GET['userid'].'" and  
				   to_user_id = (select id from tb_users where username = "'.$_GET['userprofile'].'" ) ) b on a.skill = b.skill 
				   where b.skill is NULL ');  
            	   
		  return $skillother;          
    }

   //coding by munuh   
   public function getlistuser()
   {
	    
		 	 $to_user_id = \Input::get('userid');
	 		 $skill = \Input::get('label');
	 
		//if (\Request::ajax()) {
		//	$to_user_id = 17331;
		//	$skill = 'Data Analysis';    
			     
            //$endorusers = DB::select('select b.* from tb_endorse_skills a inner join tb_users b on a.user_id = b.id  where a.to_user_id = "'.$to_user_id.'" and a.skill = "'.$skill.'"'); 
			  			 
            return $this->theme->section('profile.endorsers-user', ['endorusers' => $this->endorseRepository->getListUser($to_user_id, $skill)]);
         //echo '<pre>'; 		  
         //var_dump($this->endorseRepository->getListUser($to_user_id, $skill));die();		  
			//}
   }
       
        
	
	 
	
	   
    
}