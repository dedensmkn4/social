<div class="container page-content">
    <div class="left-column">
        {{$content}}
    </div>

    <div class="right-column">
        {{Theme::section('custompage::side')}}
    </div>
</div>