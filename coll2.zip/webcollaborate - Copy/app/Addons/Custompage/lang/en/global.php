<?php
return [
    'recent-pages' => 'Recent Pages',

];