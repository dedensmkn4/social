{{$text}}
 <a href="http://translate.yandex.com/">Powered by Yandex</a>