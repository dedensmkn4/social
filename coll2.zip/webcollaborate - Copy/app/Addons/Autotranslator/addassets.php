<?php
Theme::asset()->add('autotranslator-css', 'autotranslator::css/autotranslator.css');
Theme::asset()->add('autotranslator-js', 'autotranslator::js/autotranslator.js');