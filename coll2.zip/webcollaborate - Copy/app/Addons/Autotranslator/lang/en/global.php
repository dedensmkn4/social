<?php
return [
    'translate' => 'See translation',
    'error' => 'Couldn\'t translate it',
];