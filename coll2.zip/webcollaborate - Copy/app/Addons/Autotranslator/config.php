<?php

return [
    'yandex-key' => [
        'type' => 'text',
        'title' => 'Yandex API Key',
        'description' => 'Provide your Yandex api, if you don\'t have one you get it @www.yandex.com',
        'value' => '',
    ],

];