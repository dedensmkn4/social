<?php

namespace App\Addons\Customwidget\Classes;
use Illuminate\Database\Eloquent\Model;

/**
*
*@author: Tiamiyu waliu kola
*@website : www.crea8social.com
*/
class CustomWidget extends Model
{
    protected $table = "custom_widgets";
}