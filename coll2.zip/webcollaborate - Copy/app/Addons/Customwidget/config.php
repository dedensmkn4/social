<?php

return [
    'onlinemember-seen-by-users-s' => [
        'type' => 'boolean',
        'title' => 'Let Your Members View The Online Members Directory',
        'description' => 'This is the option to allow your members to visit the online members directory',
        'value' => '1',
    ],



];