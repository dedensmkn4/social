<div class="box">
    @if($widget->title)
        <div class="box-title">{{$widget->title}}</div>
    @endif

    <div class="box-content">
        {{$widget->content}}
    </div>
</div>