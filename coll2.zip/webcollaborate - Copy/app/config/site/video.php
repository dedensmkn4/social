<?php

return [
    'max-size-upload-video' => [
        'type' => 'integer',
        'title' => 'Set Maximum Size Upload Video',
        'description' => 'Set the maximum size upload of videos',
        'value' => '200000000',
    ],
];