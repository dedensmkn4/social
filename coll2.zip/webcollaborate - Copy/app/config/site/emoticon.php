<?php
return [
    'enable-emoticon' => [
        'type' => 'boolean',
        'title' => 'Enable/Disable Emoticons ',
        'description' => 'With this settings you can enable/disable emoticons in posts',
        'value' => '1',
    ],
];